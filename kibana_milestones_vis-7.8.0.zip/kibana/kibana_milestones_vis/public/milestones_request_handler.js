"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createMilestonesRequestHandler = createMilestonesRequestHandler;

var _public = require("../../../src/plugins/data/public");

var _constants = require("./constants");

var _services = require("./services");

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(n); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function createMilestonesRequestHandler(_ref) {
  var uiSettings = _ref.core.uiSettings;
  return /*#__PURE__*/function () {
    var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(_ref2) {
      var index, timeRange, filters, query, visParams, esClient, indexPatternTitle, esQueryConfigs, filtersDsl, request, resp;
      return regeneratorRuntime.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              index = _ref2.index, timeRange = _ref2.timeRange, filters = _ref2.filters, query = _ref2.query, visParams = _ref2.visParams;
              esClient = (0, _services.getData)().search.__LEGACY.esClient;
              indexPatternTitle = index.title;
              esQueryConfigs = _public.esQuery.getEsQueryConfig(uiSettings);
              filtersDsl = _public.esQuery.buildEsQuery(undefined, query, filters, esQueryConfigs);

              if (!(visParams.labelField === undefined || visParams.labelField === _constants.NONE_SELECTED)) {
                _context.next = 7;
                break;
              }

              return _context.abrupt("return", {
                timeFieldName: index.timeFieldName,
                data: []
              });

            case 7:
              request = {
                index: indexPatternTitle,
                body: {
                  query: {
                    bool: {
                      must: [filtersDsl, {
                        range: _defineProperty({}, index.timeFieldName, {
                          gte: timeRange.from,
                          lt: timeRange.to
                        })
                      }]
                    }
                  },
                  _source: [visParams.labelField].concat(_toConsumableArray(visParams.categoryField !== undefined && visParams.categoryField !== _constants.NONE_SELECTED ? [visParams.categoryField] : [])),
                  script_fields: {
                    milestones_timestamp: {
                      script: {
                        source: "doc[\"".concat(index.timeFieldName, "\"].value.millis")
                      }
                    }
                  },
                  size: visParams.maxDocuments,
                  sort: [_defineProperty({}, visParams.sortField, {
                    "order": visParams.sortOrder
                  })]
                }
              };
              _context.next = 10;
              return esClient.search(request);

            case 10:
              resp = _context.sent;
              return _context.abrupt("return", {
                timeFieldName: index.timeFieldName,
                data: resp.hits.hits.map(function (hit) {
                  return _objectSpread({
                    timestamp: hit.fields.milestones_timestamp[0],
                    text: hit._source[visParams.labelField]
                  }, visParams.categoryField !== undefined && visParams.category !== _constants.NONE_SELECTED ? {
                    category: hit._source[visParams.categoryField]
                  } : {});
                })
              });

            case 12:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function (_x) {
      return _ref3.apply(this, arguments);
    };
  }();
}