"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.MilestonesOptions = MilestonesOptions;

var _react = _interopRequireDefault(require("react"));

var _eui = require("@elastic/eui");

var _i18n = require("@kbn/i18n");

var _public = require("../../../../src/plugins/charts/public");

var _constants = require("../constants");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(n); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function MilestonesOptions(_ref) {
  var stateParams = _ref.stateParams,
      _setValue = _ref.setValue,
      vis = _ref.vis;

  if (typeof vis.data.indexPattern === 'undefined') {
    return null;
  }

  var fieldOptions = [{
    value: _constants.NONE_SELECTED,
    text: _constants.NONE_SELECTED
  }].concat(_toConsumableArray(vis.data.indexPattern.fields.filter(function (field) {
    return field.type === 'string' && !['_id', '_index', '_type'].includes(field.name);
  }).map(function (field) {
    return {
      value: field.name,
      text: field.name
    };
  })));
  var sortFieldOptions = [{
    value: _constants.SCORE_FIELD,
    text: _constants.SCORE_FIELD
  }].concat(_toConsumableArray(vis.data.indexPattern.fields.filter(function (field) {
    return !['_id', '_index', '_score', '_source', '_type'].includes(field.name);
  }).map(function (field) {
    return {
      value: field.name,
      text: field.name
    };
  })));
  var sortOrderOptions = [{
    value: 'asc',
    text: _i18n.i18n.translate('visTypeMilestones.visParams.textSortOrderAscending', {
      defaultMessage: 'Ascending'
    })
  }, {
    value: 'desc',
    text: _i18n.i18n.translate('visTypeMilestones.visParams.textSortOrderDescending', {
      defaultMessage: 'Descending'
    })
  }];
  return /*#__PURE__*/_react.default.createElement(_eui.EuiPanel, {
    paddingSize: "s"
  }, /*#__PURE__*/_react.default.createElement(_public.SelectOption, {
    label: _i18n.i18n.translate('visTypeMilestones.visParams.textLabelFieldLabel', {
      defaultMessage: 'Label field'
    }),
    options: fieldOptions,
    paramName: "labelField",
    value: stateParams.labelField,
    setValue: _setValue
  }), /*#__PURE__*/_react.default.createElement(_public.SelectOption, {
    label: _i18n.i18n.translate('visTypeMilestones.visParams.textCategoryFieldLabel', {
      defaultMessage: 'Category field'
    }),
    options: fieldOptions,
    paramName: "categoryField",
    value: stateParams.categoryField,
    setValue: _setValue
  }), /*#__PURE__*/_react.default.createElement(_public.SelectOption, {
    label: _i18n.i18n.translate('visTypeMilestones.visParams.textSortFieldLabel', {
      defaultMessage: 'Sort field'
    }),
    options: sortFieldOptions,
    paramName: "sortField",
    value: stateParams.sortField,
    setValue: _setValue
  }), /*#__PURE__*/_react.default.createElement(_public.SelectOption, {
    label: _i18n.i18n.translate('visTypeMilestones.visParams.textSortOrderLabel', {
      defaultMessage: 'Sort order'
    }),
    options: sortOrderOptions,
    paramName: "sortOrder",
    value: stateParams.sortOrder,
    setValue: _setValue
  }), /*#__PURE__*/_react.default.createElement(_public.SelectOption, {
    label: _i18n.i18n.translate('visTypeMilestones.visParams.textIntervalLabel', {
      defaultMessage: 'Time interval'
    }),
    options: vis.type.editorConfig.collections.intervals.map(function (i) {
      return {
        value: i,
        text: i
      };
    }),
    paramName: "interval",
    value: stateParams.interval,
    setValue: _setValue
  }), /*#__PURE__*/_react.default.createElement(_public.NumberInputOption, {
    label: _i18n.i18n.translate('visTypeMilestones.visParams.textMaxDocumentsLabel', {
      defaultMessage: 'Max documents'
    }),
    paramName: "maxDocuments",
    value: stateParams.maxDocuments,
    setValue: function setValue(paramName, value) {
      _setValue(paramName, value || 0);
    }
  }), /*#__PURE__*/_react.default.createElement(_public.SelectOption, {
    label: _i18n.i18n.translate('visTypeMilestones.visParams.textLabelArrangementLabel', {
      defaultMessage: 'Label arrangement'
    }),
    options: vis.type.editorConfig.collections.distributions.map(function (i) {
      return {
        value: i,
        text: i
      };
    }),
    paramName: "distribution",
    value: stateParams.distribution,
    setValue: _setValue
  }), /*#__PURE__*/_react.default.createElement(_public.SelectOption, {
    label: _i18n.i18n.translate('visTypeMilestones.visParams.textOrientationLabel', {
      defaultMessage: 'Orientation'
    }),
    options: vis.type.editorConfig.collections.orientation.map(function (i) {
      return {
        value: i,
        text: i
      };
    }),
    paramName: "orientation",
    value: stateParams.orientation,
    setValue: _setValue
  }), /*#__PURE__*/_react.default.createElement(_public.SwitchOption, {
    label: _i18n.i18n.translate('visTypeMilestones.visParams.renderLabelsToggleLabel', {
      defaultMessage: 'Render labels'
    }),
    paramName: "showLabels",
    value: stateParams.showLabels,
    setValue: _setValue
  }));
}